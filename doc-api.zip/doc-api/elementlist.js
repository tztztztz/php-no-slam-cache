
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Exception"],["c","inopx\\cache\\AdapterInterfaceCacheMethod"],["c","inopx\\cache\\AdapterInterfaceInputOutput"],["c","inopx\\cache\\AdapterInterfaceSynchro"],["c","inopx\\cache\\CacheMethodDummy"],["c","inopx\\cache\\CacheMethodFile"],["c","inopx\\cache\\CacheMethodMemcached"],["c","inopx\\cache\\CacheMethodPDO"],["c","inopx\\cache\\InterfaceCacheMethod"],["c","inopx\\cache\\InterfaceInputOutput"],["c","inopx\\cache\\InterfaceSynchro"],["c","inopx\\io\\IOTool"],["c","PDO"],["c","SyncReaderWriter"]];
